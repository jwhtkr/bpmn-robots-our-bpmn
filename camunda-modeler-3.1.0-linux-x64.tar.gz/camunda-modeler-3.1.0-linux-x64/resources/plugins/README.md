# Plugins Directory

Place plugins into this directory to extend the Camunda Modeler.


## Learn More

* [Example Plugins](https://github.com/camunda/camunda-modeler-plugins)
* [Plugins documentation](https://github.com/camunda/camunda-modeler/tree/v3.1.0/docs/plugins)
* [Plugin Starter Project](https://github.com/camunda/camunda-modeler-plugin-example)